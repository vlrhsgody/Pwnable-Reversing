#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Cannary Success!
void check_stack_canary(char* filepath) {
    FILE *fp;
    char command[100];
    char line[100];
    sprintf(command, "readelf -s %s | grep '__stack_chk_fail'", filepath);
    fp = popen(command, "r");
    fgets(line, sizeof(line), fp);

    if (strstr(line, "__stack_chk_fail") != NULL) {
        printf("Stack Canary: Enabled\n");
    } else {
        printf("Stack Canary: Disabled\n");
    }

    pclose(fp);
}
//DEP Success!
void check_DEP(char* filepath) {
    FILE *fp1;
    char command1[1000];
    char line1[1000];
    sprintf(command1, "readelf -l %s | grep -A 1 'GNU_STACK'", filepath);
    fp1 = popen(command1, "r");
    fgets(line1, sizeof(line1), fp1);  
    fgets(line1, sizeof(line1), fp1);  
    if (strstr(line1, "RWE") != NULL) {
        printf("DEP: Disabled\n");
    } else if (strstr(line1, "RW") != NULL) {
        printf("DEP: Enabled\n");
    }
    pclose(fp1);
}

//PIE Successed!
void check_PIE(char* filepath) {
    FILE *fp2;
    char command2[1000];
    char line2[1000];
    sprintf(command2, "readelf -h %s | grep 'Type'", filepath);
    fp2 = popen(command2, "r");
    fgets(line2, sizeof(line2), fp2);
    if (strstr(line2, "DYN") != NULL) {
        printf("PIE: Enabled\n");
    } else if (strstr(line2, "EXEC") != NULL) {
        printf("PIE: Disabled\n");
    }


    pclose(fp2);
}

int main() {
    printf("Check Started!!\n");
    printf("경로를 입력하시오 : \n");
    char filepath[1000];
    fgets(filepath, sizeof(filepath), stdin);
    filepath[strcspn(filepath, "\n")] = '\0';
    check_stack_canary(filepath);
    check_DEP(filepath);
    check_PIE(filepath);
    return 0;
}
